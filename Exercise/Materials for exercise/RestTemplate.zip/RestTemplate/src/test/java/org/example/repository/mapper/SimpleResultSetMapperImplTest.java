package org.example.repository.mapper;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SimpleResultSetMapperImplTest {

    @Test
    void map() {
    }
}