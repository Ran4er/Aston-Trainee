package org.example.service.impl;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SimpleServiceImplTest {
    //мокаем репозиторий и другие зависимости

    @Test
    void save() {
    }

    @Test
    void findById() {
    }
}