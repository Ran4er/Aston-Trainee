package org.example.servlet.mapper;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SimpleDtomapperImplTest {

    @Test
    void map() {
    }

    @Test
    void testMap() {
    }
}