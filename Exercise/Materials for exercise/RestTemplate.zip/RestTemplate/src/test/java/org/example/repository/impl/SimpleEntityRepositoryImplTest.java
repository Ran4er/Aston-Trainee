package org.example.repository.impl;

import org.junit.jupiter.api.Test;

class SimpleEntityRepositoryImplTest {

    //создаем здесь testcontainer
//    @Container
//    public static final PostgreSQLContainer<?> container =
//            new PostgreSQLContainer<>("postgres:15")
//                    .withDatabaseName("test")
//                    .withUsername("test")
//                    .withInitScript("db-migration.SQL")
//                    .withPassword("test");

    @Test
    void findById() {
    }

    @Test
    void deleteById() {
    }

    @Test
    void findAll() {
    }

    @Test
    void save() {
    }
}