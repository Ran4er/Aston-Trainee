package org.example.servlet;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SimpleServletTest {
    //мокаем сервис и другие зависимости
    // проевряем логику роута на нужные метода

    @Test
    void doGet() {
    }

    @Test
    void doPost() {
    }
}