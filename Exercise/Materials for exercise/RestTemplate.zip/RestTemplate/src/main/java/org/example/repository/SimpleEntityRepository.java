package org.example.repository;

import org.example.model.SimpleEntity;

import java.util.UUID;

public interface SimpleEntityRepository extends SimpleRepository<SimpleEntity, UUID>{
}
