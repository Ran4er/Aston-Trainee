package org.example.service.impl;

import org.example.model.SimpleEntity;
import org.example.service.SimpleService;

import java.util.UUID;

public class SimpleServiceImpl implements SimpleService {
    @Override
    public SimpleEntity save(SimpleEntity simpleEntity) {
        return null;
    }

    @Override
    public SimpleEntity findById(UUID uuid) {
        return null;
    }
}
