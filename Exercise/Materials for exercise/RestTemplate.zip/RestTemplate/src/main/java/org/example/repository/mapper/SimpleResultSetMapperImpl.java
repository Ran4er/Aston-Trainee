package org.example.repository.mapper;

import org.example.model.SimpleEntity;

import java.sql.ResultSet;

public class SimpleResultSetMapperImpl implements SimpleResultSetMapper {
    @Override
    public SimpleEntity map(ResultSet resultSet) {
        return null;
    }
}
