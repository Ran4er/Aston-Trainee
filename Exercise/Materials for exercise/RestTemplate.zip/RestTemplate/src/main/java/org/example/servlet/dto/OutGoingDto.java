package org.example.servlet.dto;

public class OutGoingDto {
}
