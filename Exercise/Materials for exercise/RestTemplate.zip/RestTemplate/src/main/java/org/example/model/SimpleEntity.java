package org.example.model;

public class SimpleEntity {
}
